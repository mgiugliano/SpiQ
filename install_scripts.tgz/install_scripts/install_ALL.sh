#!/bin/bash
#
# Installation of ALL
#
# February 21st 2022 - Michele Giugliano (mgiugliano@gmail.com)
#

source install_dotfiles.sh
